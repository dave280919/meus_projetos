var xCars = [550, 550, 550, 550, 550, 550];
var yCars = [40, 98, 150, 210, 264, 316];
var vxCars = [4, 3, 2, 2.5, 3.5, 4.5];
var wCars = 50;
var hCars = 40;

var collide = false;

function showCars(){
  for (var i = 0; i < cars.length; i = i + 1){
    image(cars[i], xCars[i], yCars[i], wCars, hCars);
  }
}

function carsMovement(){
  for (var i = 0; i < cars.length; i = i + 1){
    if (score > 0 || score < 1){
    xCars[i] = xCars[i] - vxCars[i];
      
    if (score > 4){
    xCars[i] = xCars[i] - vxCars[i] * 0.1;
      
    if (score > 9){
    xCars[i] = xCars[i] - vxCars[i] * 0.2;
      
    if (score > 14){
    xCars[i] = xCars[i] - vxCars[i] * 0.4;
      
    if (score > 19){
    xCars[i] = xCars[i] - vxCars[i] * 0.8;
    vCow = 3;
            }
          }
        }
      }
    }
  }
}
  
function resetCarsPosition(){
  for (var i = 0; i < cars.length; i = i + 1){
      if(xCars[i] < - 50){
        xCars[i] = 550;
    }
  }
}

function verifyCollision(){
  for (var i = 0; i < cars.length; i = i + 1){
    collide = collideRectCircle(xCars[i], yCars[i], wCars, hCars, xCow, yCow + hCow / 2, 15)
    
  if (collide){
    resetPosition();
      if (scoreAboveZero()){
        score = score - 1;
      }
    }
  }
}
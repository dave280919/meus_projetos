var score = 0;

function showScore(){
  textSize(25);
  fill(color(255, 240, 60));
  text(score, width / 10, 27);
}

function win(){
  if (yCow < 12){
    score = score + 1;
  }
}

function scoreAboveZero(){
  return score > 0;
}

function congratulations(){
  if (score > 24){
    textSize(50);
    fill(color(255, 69, 0));
    text('PARABÉNS', 110, 200);
  for (var i = 0; i < cars.length; i = i + 1){
    vxCars[i] = 0;
    }
    vCow = 0;
  }
}
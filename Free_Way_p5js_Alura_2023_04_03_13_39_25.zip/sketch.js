function setup() {
  createCanvas(500, 400);
  track.loop();
}

function draw() {
  background(road);
  showCow();
  showCars();
  carsMovement();
  cowMovement();
  resetCarsPosition();
  //verifyCollision();
  showScore();
  win();
  resetCow();
  congratulations();
}
// variaveis da bola
var xCircle = 300
var yCircle = 200
var dCircle = 20
var rCircle = dCircle / 2
var vxCircle = 4
var vyCircle = 4

// variaveis das raquetes
var xRect1 = 10
var xRect2 = 580
var yRect1 = 150
var yRect2 = 150
var wRect = 10
var hRect = 75

//placar
var score1 = 0
var score2 = 0

//sons
var score_sound;
var racket_sound;

//codigo
function preload(){
  score_sound = loadSound("score_sound.mp3");
  racket_sound = loadSound("racket_sound.mp3");
}

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  showcircle();
  showrects(xRect1, yRect1);
  showrects(xRect2, yRect2);
  movementcircle();
  movementrect1();
  movementrect2auto();
  verifycolisioncircleedge();
  verifycolisioncirclerect();
  showscore();
  score();
}

function showcircle(){
  circle(xCircle, yCircle, dCircle);
}

function showrects(x, y){
  rect(x, y, wRect, hRect);
}

function movementcircle(){
  xCircle = xCircle + vxCircle
  yCircle = yCircle + vyCircle
}

function movementrect1(){
  if(keyIsDown(DOWN_ARROW)){
    yRect1 = yRect1 + 10
  }
  if(keyIsDown(UP_ARROW)){
    yRect1 = yRect1 - 10
  }
}

function movementrect2auto(){
  yRect2 = yCircle - wRect / 2 - 50;
}

function verifycolisioncircleedge(){
  if(xCircle + rCircle > width || xCircle - rCircle < 0){
    vxCircle = vxCircle * -1;
    score_sound.play();
  }
  if(yCircle + rCircle > height || yCircle - rCircle < 0){
    vyCircle = vyCircle * -1;
  }
}

function verifycolisioncirclerect(){
  if (xCircle - rCircle < xRect1 + wRect && yCircle + rCircle < yRect1 + hRect && yCircle - rCircle > yRect1){
    vxCircle = vxCircle * -1;
    racket_sound.play();
  }
  if (xCircle + rCircle > xRect2 && yCircle + rCircle < yRect2 + hRect && yCircle - rCircle > yRect2){
    vxCircle = vxCircle * -1;
    racket_sound.play();
  }
}

function showscore(){
  stroke(255);
  textAlign(CENTER);
  textSize(16);
  fill(color(255,140,0));
  rect(150, 10, 40, 20);
  fill(255);
  text(score1, 170, 26);
  fill(color(255,140,0));
  rect(450, 10, 40, 20);
  fill(255);
  text(score2, 470, 26);
}

function score(){
  if(xCircle > 590){
    score1 = score1 + 1;
  }
  if(xCircle < 10){
    score2 = score2 +1;
  }
}
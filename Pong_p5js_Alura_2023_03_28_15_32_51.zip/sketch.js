//variaveis da bola
let xBola = 300
let yBola = 200
let dBola = 15
let rBola = dBola / 2

//variaveis de movimento da bola
let vxBola = 4
let vyBola = 4

//variaveis da raquete
let xRaquete = 5
let yRaquete = 162.5
let wRaquete = 5
let hRaquete = 75

//variaveis da raquete2
let xRaquete2 = 590
let yRaquete2 = 162.5
let vyRaquete2

//variaveis github
let hit = false

//placar do jogo
let p1 = 0
let p2 = 0

//sons
let raquetada;
let ponto;
let trilha;

function preload(){
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}

function setup() {
  createCanvas(600, 400);
  //trilha.loop();
}

function draw() {
  background(0);
  mostrarbola();
  //movimentarbola();
  verificarcolisaoborda();
  mostrarraquete(xRaquete, yRaquete);
  mostrarraquete(xRaquete2, yRaquete2);
  //mostrarraquete2();
  movimentarraquete();
  //movimentarraquete2();
  verificarcolisaoraquetes();
  //verificarcolisaogithub(xRaquete, yRaquete);
  //verificarcolisaogithub(xRaquete2, yRaquete2);
  movimentarraqueteauto();
  mostrarplacar();
  marcarponto();
}

function mostrarbola(){
  circle(xBola, yBola, dBola);
}

function movimentarbola(){
  xBola += vxBola;
  yBola += vyBola;
}

function verificarcolisaoborda(){
    if (xBola + rBola > width || xBola - rBola < 0){
    vxBola *= -1;
      ponto.play();
  }
  if (yBola + rBola > height || yBola - rBola < 0){
    vyBola *= -1;
  }
}

function mostrarraquete(x,y){
  rect(x, y, wRaquete, hRaquete);
}

function mostrarraquete2(){
  rect(xRaquete2, yRaquete2, wRaquete2, hRaquete2);
}

function movimentarraquete(){
  if (keyIsDown(UP_ARROW)){
    yRaquete -= 10;
  }
  if (keyIsDown(DOWN_ARROW)){
    yRaquete += 10;
  }
}

function movimentarraquete2(){
  if (keyIsDown(BACKSPACE)){
    yRaquete2 -= 10;
  }
  if (keyIsDown(ENTER)){
    yRaquete2 += 10;
  }
}

function verificarcolisaoraquetes(){
  if (xBola - rBola < xRaquete + wRaquete && yBola - rBola < yRaquete + hRaquete && yBola + rBola > yRaquete){
    vxBola *= -1;
    raquetada.play();
  }
  if (xBola + rBola > xRaquete2 && yBola - rBola > yRaquete2 && yBola + rBola < yRaquete2 + hRaquete){
    vxBola *= -1;
    raquetada.play();
  }
}

function movimentarraqueteauto(){
  vyRaquete2 = yBola - yRaquete2 - wRaquete/ 2 - 30;
  yRaquete2 += vyRaquete2
  
}

function verificarcolisaogithub(x,y){
   hit = collideRectCircle(x, y, wRaquete, hRaquete, xBola, yBola, rBola);
  if (hit){
    vxBola *= -1
  }
}

function mostrarplacar(){
  stroke(255);
  textAlign(CENTER);
  textSize(16);
  fill(color(255,140,0));
  rect(150, 10, 40, 20);
  fill(255);
  text(p1, 170, 26);
  fill(color(255,140,0));
  rect(450, 10, 40, 20);
  fill(255);
  text(p2, 470, 26);
}

function marcarponto(){
  if(xBola > 590){
    p1 += 1
  }
  if(xBola < 10){
    p2 += 1
  }
}

function colisaoraqueteborda(){
  if(yRaquete - hRaquete < 0){
    vyRaquete = 0
  }
}
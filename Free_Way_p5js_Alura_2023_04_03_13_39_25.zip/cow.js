var xCow = 10;
var yCow = 365;
var wCow = 30;
var hCow = 30;

var vCow = 2;

function showCow(){
  image(cow, xCow, yCow, wCow, hCow);
}

function cowMovement(){
  if (keyIsDown(UP_ARROW)){
    yCow = yCow - vCow;
  }
  if(keyIsDown(DOWN_ARROW)){
    if (collisionBottom()){
      yCow = yCow + vCow;
    }
  }
  if(keyIsDown(LEFT_ARROW)){
    if (collisionLeft()){
      xCow = xCow - vCow;
    }
  }
  if(keyIsDown(RIGHT_ARROW)){
      if (collisionRight()){
    xCow = xCow + vCow;
    }
  }
}

function resetCow(){
  if (yCow < 12){
    resetPosition();
  }
}

function resetPosition(){
  xCow = 10;
  yCow = 365;
}

function collisionBottom(){
  return yCow < 365;
}

function collisionRight(){
  return xCow + wCow < 500;
}

function collisionLeft(){
  return xCow > 0;
}
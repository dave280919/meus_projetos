var road;
var cow;
var car1;
var car2;
var car3;

var track;

function preload(){
  road = loadImage("images/road.png");
  cow = loadImage("images/cow.png");
  car1 = loadImage("images/car-1.png");
  car2 = loadImage("images/car-2.png");
  car3 = loadImage("images/car-3.png");
  cars = [car1, car2, car3, car1, car2, car3];
  
  track = loadSound("sounds/track.mp3");
}
